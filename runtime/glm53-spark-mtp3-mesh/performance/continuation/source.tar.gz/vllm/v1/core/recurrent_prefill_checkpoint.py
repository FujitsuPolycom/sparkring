"""Explicit recurrent checkpoint positions for bounded fresh-prefill coalescing."""
from __future__ import annotations

CheckpointPlan = tuple[int, int, tuple[int, ...]]


def validate_plan(plan: CheckpointPlan, start: int, end: int, block_size: int) -> tuple[int, ...]:
    planned_start, planned_end, targets = plan
    if (planned_start, planned_end) != (start, end):
        raise ValueError('recurrent checkpoint plan does not match the actual query span')
    if not isinstance(targets, tuple) or not 1 <= len(targets) <= 2 or targets != tuple(sorted(set(targets))):
        raise ValueError('recurrent checkpoint targets must be one or two sorted unique positions')
    if any(type(p) is not int or not start < p < end or p % block_size or (p - start) % 16 for p in targets):
        raise ValueError('recurrent checkpoint target is not a representable interior state')
    return targets


def fresh_prompt_plan(*, start: int, end: int, prompt: int, num_tokens: int,
                      block_size: int, publications: tuple[int, ...],
                      shared_prefix_boundary: int = 0) -> CheckpointPlan | None:
    # Resume, partial-tail and intermediate-prefill behavior stays in the
    # existing scheduler. This first path only appends a completely new table.
    if start != 0 or end != prompt or num_tokens != prompt or end > 8192 or end % block_size:
        return None
    required = {p for p in publications if start < p < end}
    predecessor = max((num_tokens - 1) // block_size * block_size - block_size, 0)
    if start < predecessor < end:
        required.add(predecessor)
    if start < shared_prefix_boundary < end:
        required.add(shared_prefix_boundary // block_size * block_size)
    required.discard(0)
    targets = tuple(sorted(required))
    if not targets or len(targets) > 2:
        return None
    plan = (start, end, targets)
    try:
        validate_plan(plan, start, end, block_size)
    except ValueError:
        return None
    return plan


def checkpoint_metadata(plan: CheckpointPlan | None, start: int, end: int,
                        block_size: int, capacity: int) -> tuple[list[int], list[int]]:
    if capacity not in (1, 2):
        raise ValueError('unsupported recurrent checkpoint capacity')
    if plan is not None:
        targets = validate_plan(plan, start, end, block_size)
        if capacity < len(targets):
            raise ValueError('metadata checkpoint capacity smaller than scheduled plan')
    else:
        boundary = end // block_size * block_size
        targets = ((boundary,) if end % block_size and start < boundary < end and (boundary - start) % 16 == 0 else ())
    return ([p - start for p in targets] + [0] * (capacity - len(targets)),
            [p // block_size - 1 for p in targets] + [-1] * (capacity - len(targets)))


def final_chunk_plan(*, start, end, prompt, num_tokens, block_size,
                     publications, shared_prefix_boundary=0, max_chunk_tokens=8192):
    """Exact final-chunk exports; scheduler separately proves cold provenance."""
    if (start <= 0 or start % block_size or end != prompt or num_tokens != prompt
            or end % block_size or not 0 < end - start <= min(8192, max_chunk_tokens)):
        return None
    targets = {p for p in publications if start < p < end}
    predecessor = max((num_tokens - 1) // block_size * block_size - block_size, 0)
    if start < predecessor < end:
        targets.add(predecessor)
    if start < shared_prefix_boundary < end:
        targets.add(shared_prefix_boundary // block_size * block_size)
    targets.discard(0)
    plan = (start, end, tuple(sorted(targets)))
    try:
        validate_plan(plan, start, end, block_size)
    except ValueError:
        return None
    return plan


def continuation_layout(blocks, plan, block_size, speculative_blocks):
    """Return old-column references, -1=NULL, -2=new, without mutating ownership.

    Existing desired columns retain their private physical pages. Only unused
    speculative pages move to the new suffix; the worker receives an append.
    """
    start, end, targets = plan
    validate_plan(plan, start, end, block_size)
    if start <= 0 or start % block_size or end % block_size:
        raise ValueError('continuation requires aligned nonzero source and final states')
    source = start // block_size - 1
    final = end // block_size - 1
    if speculative_blocks < 0 or len(blocks) != source + 1 + speculative_blocks:
        raise ValueError('continuation table does not end at its expected reserve')
    if blocks[source].is_null or blocks[source].ref_cnt < 1:
        raise ValueError('continuation source is not retained')
    reserve_columns = range(source + 1, len(blocks))
    for column in reserve_columns:
        block = blocks[column]
        if block.is_null or block.ref_cnt != 1 or block.block_hash is not None:
            raise ValueError('continuation reserve must be private and unhashed')
    owned = [block.block_id for block in blocks if not block.is_null]
    if len(owned) != len(set(owned)):
        raise ValueError('recurrent table aliases physical ownership')
    outputs = [p // block_size - 1 for p in targets] + [final]
    reserves = list(range(final + 1, final + 1 + speculative_blocks))
    desired = set(outputs + reserves)
    if len(desired) != len(outputs) + len(reserves):
        raise ValueError('continuation outputs alias')
    layout = list(range(len(blocks))) + [-1] * (final + 1 + speculative_blocks - len(blocks))
    movable = []
    for column in reserve_columns:
        if column not in desired:
            movable.append(column)
            layout[column] = -1
    for column in outputs:
        if column >= len(blocks):
            layout[column] = -2
    for column in reserves:
        if column >= len(blocks):
            layout[column] = movable.pop(0) if movable else -2
    if movable or layout.count(-2) != len(targets) + 1:
        raise ValueError('continuation reserve accounting differs')
    for column in desired:
        if column < len(blocks) and layout[column] != column:
            raise ValueError('continuation would replace an existing worker column')
    return source, tuple(layout)
