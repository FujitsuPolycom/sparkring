# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""DFlash block-diffusion speculator for the V2 model runner.

DFlash drafts a whole block of tokens in one draft forward: the block is
[bonus_token, MASK, MASK, ...] and every mask slot predicts the token at
its own position. Context comes from the target model's auxiliary hidden
states, which are fc-combined, normed, projected to K/V by every draft
layer, and written into the draft KV cache.
"""

from collections.abc import Mapping
from typing import Any, NamedTuple

import numpy as np
import torch
import torch.nn as nn

import vllm.envs as envs
from vllm.config import VllmConfig, replace
from vllm.config.compilation import CUDAGraphMode
from vllm.forward_context import BatchDescriptor, set_forward_context
from vllm.logger import init_logger
from vllm.triton_utils import tl, triton
from vllm.v1.attention.backend import AttentionCGSupport
from vllm.v1.attention.backends.utils import PAD_SLOT_ID
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer
from vllm.v1.worker.gpu.block_table import BlockTables
from vllm.v1.worker.gpu.cudagraph_utils import (
    BatchExecutionDescriptor,
    CudaGraphManager,
)
from vllm.v1.worker.gpu.dp_utils import dispatch_cg_and_sync_dp
from vllm.v1.worker.gpu.input_batch import InputBatch, InputBuffers
from vllm.v1.worker.gpu.model_states.interface import ModelState
from vllm.v1.worker.gpu.spec_decode.dflash.cudagraph import (
    DFlashContextCudaGraphManager,
    DFlashCudaGraphManager,
)
from vllm.v1.worker.gpu.spec_decode.dflash.utils import (
    load_dflash_model,
    maybe_load_mask_embedding,
)
from vllm.v1.worker.gpu.spec_decode.speculator import (
    CUDAGraphCapturePhase,
    DraftModelSpeculator,
)
from vllm.v1.worker.gpu.spec_decode.utils import get_parallel_drafting_token_id
from vllm.v1.worker.utils import AttentionGroup

logger = init_logger(__name__)


class _DFlashInputBatch(NamedTuple):
    num_reqs: int
    num_scheduled_tokens: np.ndarray
    positions: torch.Tensor
    query_start_loc: torch.Tensor
    idx_mapping: torch.Tensor


class DFlashSpeculator(DraftModelSpeculator):
    _speculator_name = "DFlash"  # For logging, so we can share methods with subclasses

    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        super().__init__(vllm_config, device)
        # DCP is supported by replicating the draft KV cache on every DCP
        # rank (the draft spec sets dcp_replicated): every rank writes the
        # full context KV and the block forward attends over it locally.

        self.hidden_states = torch.zeros(
            self.max_num_tokens, self.hidden_size, dtype=self.dtype, device=device
        )

        # Multimodal inputs not currently supported.
        self.supports_mm_inputs = False

        # Each request emits exactly (bonus + N mask) query tokens per step.
        self.num_query_per_req = 1 + self.num_speculative_steps
        max_query_tokens = self.max_num_reqs * self.num_query_per_req
        assert max_query_tokens <= self.max_num_tokens, (
            "max_num_batched_tokens is too small for the DFlash draft block "
            f"({max_query_tokens} > {self.max_num_tokens})."
        )

        self.parallel_drafting_token_id = get_parallel_drafting_token_id(
            self.draft_model_config.hf_config
        )

        from vllm.model_executor.models.qwen3_dflash import dflash_has_any_non_causal

        self.requires_non_causal = dflash_has_any_non_causal(
            self.draft_model_config.hf_config
        )

        # Whether the anchor query position is itself a prediction. DFlash default uses
        # the anchor as the bonus token (only mask tokens predict); DSpark samples from
        # the anchor and the N-1 mask token positions. See _prepare_dflash_inputs_kernel
        self.sample_from_anchor = False

        # Context positions for the K/V precompute. Populated by
        # prepare_dflash_inputs, and processed by the model's
        # precompute_and_store_context_kv method. NOT captured by CUDA graphs.
        self.context_positions = torch.zeros(
            self.max_num_tokens, dtype=torch.int64, device=device
        )

        # Per-request-slot count of tokens whose KV was restored (e.g. from the
        # prefix cache) at the request's last (re)admission, indexed by
        # req_state_idx. The target never ran a forward pass over them, so
        # their draft context KV was never computed; the prep kernel and the
        # block-table shift in propose() hide them from the draft's attention.
        # The runner replaces this zeros fallback via set_num_cached_tokens.
        self.num_cached_tokens = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, device=device
        )
        self.num_cached_tokens_np = np.zeros(self.max_num_reqs, dtype=np.int32)

        # Per-mask-token sampling buffers. Flattened from (num_reqs, num_spec_tokens).
        max_num_sampled_tokens = self.max_num_reqs * self.num_speculative_steps
        self.sample_indices = torch.zeros(
            max_num_sampled_tokens, dtype=torch.int64, device=device
        )
        self.sample_pos = torch.zeros(
            max_num_sampled_tokens, dtype=torch.int64, device=device
        )
        # -1 marks an inert sampling row. CUDA graph capture can execute the
        # full buffer before a real batch has populated it, so zero would make
        # every padding row race while scattering into request slot 0.
        self.sample_idx_mapping = torch.full(
            (max_num_sampled_tokens,), -1, dtype=torch.int32, device=device
        )
        # [0, 1, ..., N-1, 0, 1, ..., N-1, ...] -> the per-token column index into
        # draft_logits[req, step, :].
        self.sample_col = torch.arange(
            self.num_speculative_steps, dtype=torch.int32, device=device
        ).repeat(self.max_num_reqs)

        self.query_cudagraph_manager: DFlashCudaGraphManager | None = None
        self.context_cudagraph_manager: DFlashContextCudaGraphManager | None = None
        self.draft_kv_cache_group_id: int = -1
        # Manual CUDA graphs keep raw addresses for model intermediates. Retain
        # each captured backbone output so its storage cannot be recycled while
        # a graph still reads it during sampling.
        self._captured_backbone_outputs: list[torch.Tensor] = []
        self.dynamic_physical_depth = (
            envs.VLLM_DSPARK_DYNAMIC_DRAFT_DEPTH and self._speculator_name == "DSpark"
        )

    def _query_len_for_speculative_steps(self, num_speculative_steps: int) -> int:
        return (
            num_speculative_steps
            if self.sample_from_anchor
            else 1 + num_speculative_steps
        )

    def _speculative_steps_for_query_len(self, query_len: int) -> int:
        return query_len if self.sample_from_anchor else query_len - 1

    @property
    def attn_vllm_config(self) -> VllmConfig:
        # The draft's attention differs from the target's in causality.
        return replace(
            self.vllm_config,
            attention_config=replace(
                self.vllm_config.attention_config,
                use_non_causal=self.requires_non_causal,
            ),
        )

    def init_cudagraph_manager(self, cudagraph_mode: CUDAGraphMode) -> None:
        wants_full = cudagraph_mode.decode_mode() == CUDAGraphMode.FULL
        supports_full = (
            self.attn_cg_support.min_cg_support.value
            >= AttentionCGSupport.UNIFORM_BATCH.value
        )
        if wants_full and not supports_full:
            logger.warning(
                "%s draft attention (%s) does not support full CUDA graphs; "
                "running the draft eagerly.",
                self._speculator_name,
                self.attn_cg_support.min_cg_attn_backend,
            )
        # PIECEWISE cudagraphs are not supported for dflash.
        if wants_full and supports_full:
            cudagraph_mode = CUDAGraphMode.FULL_DECODE_ONLY
        else:
            cudagraph_mode = CUDAGraphMode.NONE

        self.query_cudagraph_manager = DFlashCudaGraphManager(
            self.vllm_config,
            self.device,
            cudagraph_mode,
            decode_query_len=self.num_query_per_req,
        )
        if wants_full and supports_full and self._speculator_name == "DSpark":
            self.context_cudagraph_manager = DFlashContextCudaGraphManager(
                self.vllm_config,
                self.device,
                max_num_context_tokens=self.max_num_tokens,
            )

    def capture(self, *, capture_phase: CUDAGraphCapturePhase) -> None:
        logger.info("Capturing model for %s speculator...", self._speculator_name)
        # Reset sampling indices to prevent stale values from prior dummy runs
        # from being baked into the captured graph. Mapping rows stay inert.
        self.sample_indices.zero_()
        self.sample_pos.zero_()
        self.sample_idx_mapping.fill_(-1)
        assert self.query_cudagraph_manager is not None
        self.query_cudagraph_manager.capture(
            self._generate_draft,
            self.input_buffers,
            self.block_tables,
            self.attn_groups,
            self.kv_cache_config,
            self.max_model_len,
            causal=self._group_causal,
            channel_id=f"vllm:draft:dflash:{capture_phase}",
            progress_bar_desc=f"Capturing {self._speculator_name.lower()} CUDA graphs",
        )
        if self.context_cudagraph_manager is not None:
            self._context_slot_mappings.fill_(PAD_SLOT_ID)
            self.context_positions.zero_()
            self.context_cudagraph_manager.capture_context(
                self._capture_context_kv,
                channel_id=f"vllm:draft:dflash:context:{capture_phase}",
            )

    def get_cudagraph_managers(self) -> tuple[CudaGraphManager, ...]:
        managers: list[CudaGraphManager] = []
        if self.query_cudagraph_manager is not None:
            managers.append(self.query_cudagraph_manager)
        if self.context_cudagraph_manager is not None:
            managers.append(self.context_cudagraph_manager)
        return tuple(managers)

    def clear_cudagraphs(self) -> None:
        super().clear_cudagraphs()
        self._captured_backbone_outputs.clear()

    def _warmup_prepare_inputs_kernel(self) -> None:
        if self.draft_kv_cache_group_id < 0:
            return

        target_query_lens = {
            self.num_query_per_req + 1,
            32,
            128,
            256,
            1024,
        }
        draft_query_lens = (
            range(1, self.num_query_per_req + 1)
            if self.dynamic_physical_depth
            else (self.num_query_per_req,)
        )
        for target_query_len in sorted(target_query_lens):
            num_reqs = max(
                1,
                min(
                    self.max_num_reqs,
                    self.max_num_tokens // target_query_len,
                ),
            )
            num_tokens = num_reqs * target_query_len
            positions = torch.arange(
                num_tokens,
                dtype=torch.int64,
                device=self.device,
            )
            query_start_loc = torch.arange(
                0,
                num_tokens + 1,
                target_query_len,
                dtype=torch.int32,
                device=self.device,
            )
            idx_mapping = torch.arange(
                num_reqs,
                dtype=torch.int32,
                device=self.device,
            )
            input_batch = _DFlashInputBatch(
                num_reqs,
                np.full(
                    num_reqs,
                    target_query_len,
                    dtype=np.int32,
                ),
                positions,
                query_start_loc,
                idx_mapping,
            )
            num_sampled = torch.zeros(num_reqs, dtype=torch.int32, device=self.device)
            num_rejected = torch.zeros_like(num_sampled)
            last_sampled = torch.zeros(
                self.max_num_reqs,
                dtype=torch.int32,
                device=self.device,
            )
            next_prefill_tokens = torch.zeros_like(last_sampled)

            for draft_query_len in draft_query_lens:
                num_speculative_steps = self._speculative_steps_for_query_len(
                    draft_query_len
                )
                for i, gid in enumerate(self.draft_kv_cache_group_ids):
                    prepare_dflash_inputs(
                        self.input_buffers,
                        self.block_tables.slot_mappings[gid],
                        self.context_positions,
                        self._context_slot_mappings[i],
                        self.sample_indices,
                        self.sample_pos,
                        self.sample_idx_mapping,
                        input_batch,
                        num_sampled,
                        num_rejected,
                        last_sampled,
                        next_prefill_tokens,
                        self.block_tables.input_block_tables[gid],
                        self.block_tables.kernel_block_sizes[gid],
                        self.num_cached_tokens,
                        self.parallel_drafting_token_id,
                        draft_query_len,
                        num_speculative_steps,
                        self.max_num_reqs,
                        self.max_num_tokens,
                        self.max_model_len,
                        self.sample_from_anchor,
                    )

    def load_draft_model(
        self,
        target_model: nn.Module,
        target_attn_layer_names: set[str],
    ) -> nn.Module:
        model = load_dflash_model(target_model, self.vllm_config)
        maybe_load_mask_embedding(
            model,
            self.draft_model_config.model,
            self.parallel_drafting_token_id,
        )
        return model

    def set_num_cached_tokens(
        self,
        num_cached_tokens: torch.Tensor,
        num_cached_tokens_np: np.ndarray,
    ) -> None:
        """Register the runner's per-request-slot cache-restored token counts.

        Indexed by req_state_idx; see the buffer comment in __init__.
        """
        self.num_cached_tokens = num_cached_tokens
        self.num_cached_tokens_np = num_cached_tokens_np

    def _has_unaligned_cached_prefix(self, input_batch: InputBatch) -> bool:
        req_state_indices = input_batch.idx_mapping_np[: input_batch.num_reqs]
        cached = self.num_cached_tokens_np[req_state_indices]
        return any(
            np.any(cached % block_size != 0)
            for block_size in self.block_tables.kernel_block_sizes
        )

    def set_attn(
        self,
        model_state: ModelState,
        kv_cache_config: KVCacheConfig,
        block_tables: BlockTables,
        target_input_buffers: InputBuffers,
        target_attn_groups: list[list[AttentionGroup]],
    ) -> None:
        super().set_attn(
            model_state,
            kv_cache_config,
            block_tables,
            target_input_buffers,
            target_attn_groups,
        )

        self.draft_kv_cache_group_ids = [
            gid for gid, g in enumerate(self.attn_groups) if g
        ]
        assert self.draft_kv_cache_group_ids, "No draft attention groups found."
        self.draft_kv_cache_group_id = self.draft_kv_cache_group_ids[0]
        # The shared seq_lens buffer carries the cache-shifted draft sequence
        # lengths (see _prepare_dflash_inputs_kernel), which only works if all
        # draft groups shift by the same number of slots per cached block.
        draft_block_sizes = {
            self.block_tables.kernel_block_sizes[gid]
            for gid in self.draft_kv_cache_group_ids
        }
        assert len(draft_block_sizes) == 1, (
            "DFlash requires a uniform block size across draft KV cache "
            f"groups, got {draft_block_sizes}."
        )

        # Per-group context slot buffers for the precompute (one row per group).
        self._context_slot_mappings = torch.full(
            (len(self.draft_kv_cache_group_ids), self.max_num_tokens),
            PAD_SLOT_ID,
            dtype=torch.int64,
            device=self.device,
        )

        # Map each draft decoder layer to the index (within draft_kv_cache_group_ids)
        # of the kv-cache group its cache belongs to. Models that share a single group
        # leave this as None and share one context slot mapping.
        self._layer_group_idx: list[int] | None = None
        # Per-KV-group causal, falling back to whether the drafter is all-causal.
        self._group_causal: dict[int, bool] | bool = not self.requires_non_causal
        if hasattr(self.model, "get_draft_kv_cache_layer_names"):
            layer_names = self.model.get_draft_kv_cache_layer_names()
            name_to_gid = {
                ln: gid
                for gid, group in enumerate(kv_cache_config.kv_cache_groups)
                for ln in group.layer_names
            }
            gid_to_idx = {gid: i for i, gid in enumerate(self.draft_kv_cache_group_ids)}
            self._layer_group_idx = [
                gid_to_idx[name_to_gid[name]] for name in layer_names
            ]
            if hasattr(self.model, "get_draft_attn_causal"):
                self._group_causal = {
                    name_to_gid[name]: layer_causal
                    for name, layer_causal in zip(
                        layer_names, self.model.get_draft_attn_causal()
                    )
                }

    @torch.inference_mode()
    def _run_model(
        self,
        num_tokens: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
    ) -> torch.Tensor:
        batch_descriptor = BatchDescriptor(num_tokens=num_tokens)
        with set_forward_context(
            attn_metadata,
            self.vllm_config,
            num_tokens=num_tokens,
            cudagraph_runtime_mode=cudagraph_runtime_mode,
            num_tokens_across_dp=num_tokens_across_dp,
            slot_mapping=slot_mappings,
            batch_descriptor=batch_descriptor,
        ):
            last_hidden_states = self.model(
                input_ids=self.input_buffers.input_ids[:num_tokens],
                positions=self.input_buffers.positions[:num_tokens],
                inputs_embeds=None,
            )
        return last_hidden_states

    def _context_slots_for_layers(
        self,
        num_tokens: int,
    ) -> torch.Tensor | list[torch.Tensor]:
        if self._layer_group_idx is not None:
            return [
                self._context_slot_mappings[gidx][:num_tokens]
                for gidx in self._layer_group_idx
            ]
        return self._context_slot_mappings[0][:num_tokens]

    def _capture_context_kv(self, num_tokens: int) -> None:
        self.model.precompute_and_store_context_kv(
            self.hidden_states[:num_tokens],
            self.context_positions[:num_tokens],
            self._context_slots_for_layers(num_tokens),
        )

    def _precompute_context_kv(
        self,
        num_target_tokens: int,
        batch_desc: BatchExecutionDescriptor,
        context_slots: torch.Tensor | list[torch.Tensor | None] | None,
    ) -> None:
        if batch_desc.cg_mode == CUDAGraphMode.FULL:
            assert self.context_cudagraph_manager is not None
            self.context_cudagraph_manager.run_fullgraph(batch_desc)
            return
        self.model.precompute_and_store_context_kv(
            self.hidden_states[:num_target_tokens],
            self.context_positions[:num_target_tokens],
            context_slots,
        )

    def _generate_draft(
        self,
        num_reqs: int,
        num_tokens_padded: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
        is_profile: bool = False,
        num_query_per_req: int | None = None,
    ) -> None:
        if num_query_per_req is None:
            num_speculative_steps = self.num_speculative_steps
        else:
            num_speculative_steps = self._speculative_steps_for_query_len(
                num_query_per_req
            )
        last_hidden_states = self._run_model(
            num_tokens_padded,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
        )
        if torch.cuda.is_current_stream_capturing():
            self._captured_backbone_outputs.append(last_hidden_states)

        num_sample = num_reqs * num_speculative_steps
        sample_hidden_states = last_hidden_states[self.sample_indices[:num_sample]]
        # sample_pos is the predicted token's position Q; sample_draft keys
        # the (salted) draft Gumbel stream by positions + 1, so pass Q-2 to
        # get a key unique per predicted position.
        draft_tokens = self.sample_draft(
            sample_hidden_states,
            self.sample_pos[:num_sample] - 2,
            self.sample_idx_mapping[:num_sample],
            self.temperature,
            self.seeds,
            self.sample_col[:num_sample],
            self.draft_logits,
        )
        self.draft_tokens[:num_reqs, :num_speculative_steps] = draft_tokens.view(
            num_reqs, num_speculative_steps
        )

    def _build_draft_attn_metadata(
        self,
        num_reqs: int,
        num_reqs_padded: int,
        num_tokens_padded: int,
        num_query_per_req: int | None = None,
        causal: bool | Mapping[int, bool] = False,
    ) -> dict[str, Any] | None:
        if not self.draft_attn_layer_names:
            return None
        if num_query_per_req is None:
            num_query_per_req = self.num_query_per_req
        return super()._build_draft_attn_metadata(
            num_reqs,
            num_reqs_padded,
            num_tokens_padded,
            num_query_per_req=num_query_per_req,
            causal=causal,
        )

    @torch.inference_mode()
    def propose(
        self,
        input_batch: InputBatch,
        attn_metadata: dict[str, Any],
        slot_mappings: dict[str, torch.Tensor],
        # [num_tokens, hidden_size]
        last_hidden_states: torch.Tensor,
        # num_layers x [num_tokens, hidden_size]
        aux_hidden_states: list[torch.Tensor] | None,
        # [num_reqs]
        num_sampled: torch.Tensor,
        # [num_reqs]
        num_rejected: torch.Tensor,
        # [max_num_reqs]
        last_sampled: torch.Tensor,
        # [max_num_reqs]
        next_prefill_tokens: torch.Tensor,
        # [max_num_reqs]
        temperature: torch.Tensor,
        # [max_num_reqs]
        seeds: torch.Tensor,
        num_speculative_tokens: int | None = None,
        num_tokens_across_dp: torch.Tensor | None = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        is_profile: bool = False,
    ) -> torch.Tensor:
        num_reqs = input_batch.num_reqs
        num_target_tokens = input_batch.num_tokens
        if not dummy_run and self._has_unaligned_cached_prefix(input_batch):
            logger.warning_once(
                "DFlash/DSpark drafting is disabled for a batch containing a "
                "block-unaligned cache-restored prefix because draft KV is "
                "not available for the restored partial block."
            )
            self.draft_tokens[:num_reqs].fill_(-1)
            return self.draft_tokens[:num_reqs]
        active_num_speculative_steps = self.num_speculative_steps
        if self.dynamic_physical_depth and num_speculative_tokens is not None:
            active_num_speculative_steps = num_speculative_tokens
        if not 1 <= active_num_speculative_steps <= self.num_speculative_steps:
            raise ValueError(
                "DSpark physical draft depth must be between 1 and "
                f"{self.num_speculative_steps}, got {active_num_speculative_steps}."
            )
        active_query_len = self._query_len_for_speculative_steps(
            active_num_speculative_steps
        )
        num_query_tokens = num_reqs * active_query_len
        max_seq_len = input_batch.seq_lens_cpu_upper_bound[:num_reqs].max().item()
        self.draft_max_seq_len = min(max_seq_len + active_query_len, self.max_model_len)

        # NOTE: To avoid CPU-GPU synchronization without CPU knowing the
        # number of rejected tokens, we maintain the size of input_ids and
        # hidden_states the same as the target model's. This means, we pad each
        # request's query length to include any rejected positions.
        if aux_hidden_states:
            hidden_states = self.model.combine_hidden_states(
                torch.cat(aux_hidden_states, dim=-1)
            )
        else:
            hidden_states = last_hidden_states
        self.hidden_states[:num_target_tokens].copy_(hidden_states[:num_target_tokens])

        self._copy_request_inputs(
            num_reqs,
            input_batch.idx_mapping,
            temperature,
            seeds,
        )

        if dummy_run and skip_attn_for_dummy_run:
            # Memory profiling path: block_tables / kv_cache_config are not initialized.
            # Since DFlash needs to build its own attention metadata, we must skip the
            # preparation in this path and run a minimal forward pass.
            self.model.precompute_and_store_context_kv(
                self.hidden_states[:num_target_tokens],
                self.context_positions[:num_target_tokens],
            )
            # DFlash processes all speculative tokens in one forward pass,
            # so the real token count is num_query_tokens.
            self._prepare_eplb_forward(num_query_tokens)
            self._generate_draft(
                num_reqs,
                num_query_tokens,
                attn_metadata=None,
                slot_mappings=None,
                num_tokens_across_dp=num_tokens_across_dp,
                cudagraph_runtime_mode=CUDAGraphMode.NONE,
                is_profile=is_profile,
                num_query_per_req=active_query_len,
            )
            return self.draft_tokens[:num_reqs, :active_num_speculative_steps]

        # The query slot mapping is written into the shared BlockTables slot_mappings.
        # That buffer's address is what the captured CUDA graph reads from at replay.
        assert self.draft_kv_cache_group_id >= 0
        if self.context_cudagraph_manager is not None and not (dummy_run or is_profile):
            context_batch_desc = self.context_cudagraph_manager.dispatch_context(
                num_target_tokens
            )
        else:
            context_batch_desc = BatchExecutionDescriptor(
                cg_mode=CUDAGraphMode.NONE,
                num_tokens=num_target_tokens,
                num_reqs=None,
            )
        context_num_tokens_padded = context_batch_desc.num_tokens
        # Support multiple draft KV cache groups by preparing inputs once for each
        for i, gid in enumerate(self.draft_kv_cache_group_ids):
            prepare_dflash_inputs(
                self.input_buffers,
                self.block_tables.slot_mappings[gid],
                self.context_positions,
                self._context_slot_mappings[i],
                self.sample_indices,
                self.sample_pos,
                self.sample_idx_mapping,
                input_batch,
                num_sampled,
                num_rejected,
                last_sampled,
                next_prefill_tokens,
                self.block_tables.input_block_tables[gid],
                self.block_tables.kernel_block_sizes[gid],
                self.num_cached_tokens,
                self.parallel_drafting_token_id,
                active_query_len,
                active_num_speculative_steps,
                self.max_num_reqs,
                self.max_num_tokens,
                self.max_model_len,
                self.sample_from_anchor,
                context_num_tokens_padded=context_num_tokens_padded,
            )

        # Cache-restored tokens (e.g. prefix-cache hits) never flowed through
        # the target forward, so their draft context KV was never written and
        # their cache slots hold garbage. Hide them from the draft's
        # attention: shift each draft block-table row left by the restored
        # whole blocks (the prep kernel shortened seq_lens to match). Runs
        # after prepare_dflash_inputs because the slot mappings index the
        # unshifted table; in-place is safe because input_block_tables are
        # regathered from the persistent block tables every step. Up to
        # Non-aligned restored prefixes fail closed before this path because a
        # block-table shift cannot hide the residual partial block. Skipped for
        # dummy runs, whose idx_mapping does not reference live requests.
        if not dummy_run:
            for gid in self.draft_kv_cache_group_ids:
                shift_draft_block_tables(
                    self.block_tables.input_block_tables[gid],
                    input_batch.idx_mapping,
                    self.num_cached_tokens,
                    self.input_buffers.seq_lens,
                    self.block_tables.kernel_block_sizes[gid],
                )

        # Pre-insert context K/V into the cache. Decode replays a row-bucketed
        # FULL graph; profiling, dummy, and out-of-envelope shapes remain eager.
        # Each layer uses the context slots of its own kv-cache group.
        if dummy_run:
            context_slots: torch.Tensor | list[torch.Tensor | None] | None = None
        elif self._layer_group_idx is not None:
            context_slots = [
                self._context_slot_mappings[gidx][:num_target_tokens]
                for gidx in self._layer_group_idx
            ]
        else:
            context_slots = self._context_slot_mappings[0][:num_target_tokens]
        self._precompute_context_kv(
            num_target_tokens,
            context_batch_desc,
            context_slots,
        )

        # Every DFlash step has exactly num_query_per_req tokens, so we can use FULL CGs
        batch_desc, num_tokens_across_dp = dispatch_cg_and_sync_dp(
            self.query_cudagraph_manager,
            num_reqs,
            num_query_tokens,
            uniform_token_count=active_query_len,
            max_req_tokens=None,
            dp_size=self.dp_size,
            dp_rank=self.dp_rank,
            need_eager=is_profile,
        )

        num_reqs_padded = batch_desc.num_reqs or num_reqs
        num_tokens_padded = batch_desc.num_tokens

        # Rebuild the draft attention metadata even when replaying the FULL
        # graph so that any attention metadata builder state is updated.
        draft_attn_metadata = self._build_draft_attn_metadata(
            num_reqs=num_reqs,
            num_reqs_padded=num_reqs_padded,
            num_tokens_padded=num_tokens_padded,
            num_query_per_req=active_query_len,
            causal=self._group_causal,
        )
        draft_slot_mappings_by_layer = build_slot_mappings_by_layer(
            self.block_tables.slot_mappings[:, :num_tokens_padded],
            self.kv_cache_config,
        )

        # DFlash processes all speculative tokens in one forward pass,
        # so the real token count is num_query_tokens.
        self._prepare_eplb_forward(num_query_tokens)

        if batch_desc.cg_mode == CUDAGraphMode.FULL:
            assert self.query_cudagraph_manager is not None
            self.query_cudagraph_manager.run_fullgraph(batch_desc)
        else:
            self._generate_draft(
                num_reqs,
                num_tokens_padded,
                draft_attn_metadata,
                draft_slot_mappings_by_layer,
                num_tokens_across_dp=num_tokens_across_dp,
                cudagraph_runtime_mode=batch_desc.cg_mode,
                is_profile=is_profile,
                num_query_per_req=active_query_len,
            )

        return self.draft_tokens[:num_reqs, :active_num_speculative_steps]


@triton.jit
def _prepare_dflash_inputs_kernel(
    # Outputs
    out_input_ids_ptr,
    out_query_positions_ptr,
    out_query_start_loc_ptr,
    out_seq_lens_ptr,
    out_query_slot_mapping_ptr,
    out_context_positions_ptr,
    out_context_slot_mapping_ptr,
    out_sample_indices_ptr,
    out_sample_pos_ptr,
    out_sample_idx_mapping_ptr,
    # Inputs from target batch
    target_positions_ptr,
    target_query_start_loc_ptr,
    idx_mapping_ptr,
    last_sampled_ptr,
    next_prefill_tokens_ptr,
    num_sampled_ptr,
    num_rejected_ptr,
    # Block table for slot mapping lookup.
    block_table_ptr,
    block_table_stride,
    # [max_num_reqs] cache-restored token counts, indexed by req_state_idx.
    num_cached_tokens_ptr,
    # Scalars
    parallel_drafting_token_id,
    block_size,
    num_query_per_req,
    num_speculative_steps,
    max_num_reqs,
    max_num_tokens,
    max_model_len,
    context_num_tokens_padded,
    SAMPLE_FROM_ANCHOR: tl.constexpr,
    PAD_SLOT_ID: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    block_idx = tl.program_id(1)
    num_reqs = tl.num_programs(0)
    req_state_idx = tl.load(idx_mapping_ptr + req_idx)

    ctx_start = tl.load(target_query_start_loc_ptr + req_idx)
    ctx_end = tl.load(target_query_start_loc_ptr + req_idx + 1)
    num_ctx = ctx_end - ctx_start

    num_rejected = tl.load(num_rejected_ptr + req_idx)
    valid_ctx_end = ctx_end - num_rejected
    num_valid_ctx = valid_ctx_end - ctx_start

    num_sampled = tl.load(num_sampled_ptr + req_idx)
    if num_sampled > 0:
        bonus_token = tl.load(last_sampled_ptr + req_state_idx).to(tl.int32)
    else:
        # Chunked prefilling: splice in the next prefill token.
        bonus_token = tl.load(next_prefill_tokens_ptr + req_state_idx).to(tl.int32)

    last_valid_pos = tl.load(target_positions_ptr + valid_ctx_end - 1)
    query_base = req_idx * num_query_per_req

    j = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    is_ctx = j < num_ctx
    is_valid_ctx = j < num_valid_ctx
    is_query = (j >= num_valid_ctx) & (j < num_valid_ctx + num_query_per_req)
    query_off = j - num_valid_ctx

    # --- Context positions / slots ---
    ctx_pos_idx = ctx_start + tl.where(is_ctx, j, 0)
    ctx_pos = tl.load(target_positions_ptr + ctx_pos_idx, mask=is_valid_ctx, other=0)
    ctx_block_num = ctx_pos // block_size
    ctx_block_num = tl.minimum(ctx_block_num, block_table_stride - 1)
    ctx_block_id = tl.load(
        block_table_ptr + req_idx * block_table_stride + ctx_block_num,
        mask=is_valid_ctx,
        other=0,
    ).to(tl.int64)
    # Sliding-window draft KV: old context positions can be evicted and point
    # at the null block. Map those to PAD so the cache-write kernel skips them
    # instead of clobbering physical block 0.
    ctx_resident = is_ctx & (ctx_block_id != 0)
    ctx_slot = tl.where(
        ctx_resident,
        ctx_block_id * block_size + (ctx_pos % block_size),
        PAD_SLOT_ID,
    )
    tl.store(out_context_positions_ptr + ctx_start + j, ctx_pos, mask=is_ctx)
    tl.store(
        out_context_slot_mapping_ptr + ctx_start + j,
        tl.where(is_valid_ctx, ctx_slot, PAD_SLOT_ID),
        mask=is_ctx,
    )

    # --- Query positions / input_ids / slots ---
    query_pos = last_valid_pos + 1 + query_off
    query_idx = query_base + query_off
    is_bonus = is_query & (query_off == 0)
    input_id = tl.where(is_bonus, bonus_token, parallel_drafting_token_id)

    q_block_num = query_pos // block_size
    q_block_num = tl.minimum(q_block_num, block_table_stride - 1)
    q_block_id = tl.load(
        block_table_ptr + req_idx * block_table_stride + q_block_num,
        mask=is_query,
        other=0,
    ).to(tl.int64)
    # Prefix-cache hits for DCP-replicated DFlash replay a resident
    # sliding-window tail with null padding for evicted/global positions.
    # Do not treat the null block as a real writable cache slot.
    q_resident = is_query & (q_block_id != 0)
    q_slot = tl.where(
        q_resident,
        q_block_id * block_size + (query_pos % block_size),
        PAD_SLOT_ID,
    )

    tl.store(out_input_ids_ptr + query_idx, input_id, mask=is_query)
    clamped_query_pos = tl.minimum(query_pos, max_model_len - 1)
    tl.store(out_query_positions_ptr + query_idx, clamped_query_pos, mask=is_query)
    tl.store(out_query_slot_mapping_ptr + query_idx, q_slot, mask=is_query)

    # --- Sample indices / positions / idx_mapping ---
    # When SAMPLE_FROM_ANCHOR (DSpark), so we sample at EVERY query position
    # and each position k predicts the NEXT token (sampled position = query_pos + 1).
    # Otherwise (DFlash default) the anchor is the bonus token and only the mask tokens
    # at offsets > 0 are sampled from, each AT its own position.
    sample_off = 0 if SAMPLE_FROM_ANCHOR else 1
    is_sample = is_query & (query_off >= sample_off)
    sample_idx = req_idx * num_speculative_steps + (query_off - sample_off)
    sample_pos = query_pos + 1 if SAMPLE_FROM_ANCHOR else query_pos
    tl.store(out_sample_indices_ptr + sample_idx, query_idx, mask=is_sample)
    tl.store(out_sample_pos_ptr + sample_idx, sample_pos, mask=is_sample)
    tl.store(out_sample_idx_mapping_ptr + sample_idx, req_state_idx, mask=is_sample)

    if block_idx == 0:
        tl.store(out_query_start_loc_ptr + req_idx, query_base)
        # seq_lens is the absolute sequence length the draft attention
        # reads up to (context + query), not just the count of accepted
        # tokens this step — minus the cache-restored whole blocks, which
        # hold no draft KV and are shifted out of the block table (see
        # shift_draft_block_tables).
        num_cached = tl.load(num_cached_tokens_ptr + req_state_idx)
        num_shifted_slots = (num_cached // block_size) * block_size
        # The clamp guards dummy runs, where req_state_idx may point at a
        # stale slot whose cached count exceeds the dummy sequence length.
        tl.store(
            out_seq_lens_ptr + req_idx,
            tl.maximum(
                last_valid_pos + 1 + num_query_per_req - num_shifted_slots,
                num_query_per_req,
            ),
        )
        if req_idx == num_reqs - 1:
            # Pad per-request buffers to max_num_reqs for CUDA graph safety.
            last_query_end = num_reqs * num_query_per_req
            for i in range(num_reqs, max_num_reqs + 1, BLOCK_SIZE):
                block = i + tl.arange(0, BLOCK_SIZE)
                mask = block < max_num_reqs + 1
                tl.store(out_query_start_loc_ptr + block, last_query_end, mask=mask)
            for i in range(num_reqs, max_num_reqs, BLOCK_SIZE):
                block = i + tl.arange(0, BLOCK_SIZE)
                mask = block < max_num_reqs
                tl.store(out_seq_lens_ptr + block, 0, mask=mask)
            # Padded sample slots point at query index 0 (a valid row in
            # last_hidden_states) so CG replay never reads OOB. Padded
            # sample idx mappings point to -1, which is ignored during
            # sampling to prevent writing stale values to draft logits.
            pad_start = num_reqs * num_speculative_steps
            pad_end = max_num_reqs * num_speculative_steps
            for i in range(pad_start, pad_end, BLOCK_SIZE):
                block = i + tl.arange(0, BLOCK_SIZE)
                mask = block < pad_end
                tl.store(out_sample_indices_ptr + block, 0, mask=mask)
                tl.store(out_sample_pos_ptr + block, 0, mask=mask)
                tl.store(out_sample_idx_mapping_ptr + block, -1, mask=mask)
            # Pad query slot mappings past num_query_tokens with PAD so the
            # captured CG sees PAD slots (no K/V write) for replay sizes
            # larger than the current request count.
            q_pad_start = num_reqs * num_query_per_req
            for i in range(q_pad_start, max_num_tokens, BLOCK_SIZE):
                block = i + tl.arange(0, BLOCK_SIZE)
                mask = block < max_num_tokens
                tl.store(out_input_ids_ptr + block, 0, mask=mask)
                tl.store(out_query_positions_ptr + block, 0, mask=mask)
                tl.store(out_query_slot_mapping_ptr + block, PAD_SLOT_ID, mask=mask)
            # Context-KV graphs round the actual target rows up to a capture
            # bucket. Keep padded rows in-range and suppress their cache writes.
            for i in range(ctx_end, context_num_tokens_padded, BLOCK_SIZE):
                block = i + tl.arange(0, BLOCK_SIZE)
                mask = block < context_num_tokens_padded
                tl.store(out_context_positions_ptr + block, 0, mask=mask)
                tl.store(out_context_slot_mapping_ptr + block, PAD_SLOT_ID, mask=mask)


def prepare_dflash_inputs(
    input_buffers: InputBuffers,
    query_slot_mapping: torch.Tensor,
    context_positions: torch.Tensor,
    context_slot_mapping: torch.Tensor,
    sample_indices: torch.Tensor,
    sample_pos: torch.Tensor,
    sample_idx_mapping: torch.Tensor,
    input_batch: InputBatch | _DFlashInputBatch,
    # [num_reqs]
    num_sampled: torch.Tensor,
    # [num_reqs]
    num_rejected: torch.Tensor,
    # [max_num_reqs]
    last_sampled: torch.Tensor,
    # [max_num_reqs]
    next_prefill_tokens: torch.Tensor,
    # [max_num_reqs, max_num_blocks]
    block_table: torch.Tensor,
    block_size: int,
    # [max_num_reqs]
    num_cached_tokens: torch.Tensor,
    parallel_drafting_token_id: int,
    num_query_per_req: int,
    num_speculative_steps: int,
    max_num_reqs: int,
    max_num_tokens: int,
    max_model_len: int,
    sample_from_anchor: bool = False,
    context_num_tokens_padded: int | None = None,
) -> None:
    num_reqs = input_batch.num_reqs
    assert num_reqs > 0
    # Cover the longest possible per-request span (ctx + query). Use the max
    # per-request query length, not the total token count across the batch.
    max_target_query_len = int(input_batch.num_scheduled_tokens.max())
    max_tokens_per_req = max_target_query_len + num_query_per_req
    BLOCK_SIZE = min(256, triton.next_power_of_2(max(1, max_tokens_per_req)))
    num_blocks = triton.cdiv(max_tokens_per_req, BLOCK_SIZE)
    num_context_tokens = int(input_batch.num_scheduled_tokens.sum())
    if context_num_tokens_padded is None:
        context_num_tokens_padded = num_context_tokens
    if not num_context_tokens <= context_num_tokens_padded <= max_num_tokens:
        raise ValueError(
            "DFlash context graph padding must cover the actual context rows "
            f"without exceeding the input buffer: actual={num_context_tokens}, "
            f"padded={context_num_tokens_padded}, max={max_num_tokens}."
        )
    _prepare_dflash_inputs_kernel[(num_reqs, num_blocks)](
        input_buffers.input_ids,
        input_buffers.positions,
        input_buffers.query_start_loc,
        input_buffers.seq_lens,
        query_slot_mapping,
        context_positions,
        context_slot_mapping,
        sample_indices,
        sample_pos,
        sample_idx_mapping,
        input_batch.positions,
        input_batch.query_start_loc,
        input_batch.idx_mapping,
        last_sampled,
        next_prefill_tokens,
        num_sampled,
        num_rejected,
        block_table,
        block_table.stride(0),
        num_cached_tokens,
        parallel_drafting_token_id,
        block_size,
        num_query_per_req,
        num_speculative_steps,
        max_num_reqs,
        max_num_tokens,
        max_model_len,
        context_num_tokens_padded,
        SAMPLE_FROM_ANCHOR=sample_from_anchor,
        PAD_SLOT_ID=PAD_SLOT_ID,
        BLOCK_SIZE=BLOCK_SIZE,
    )


@triton.jit
def _shift_draft_block_tables_kernel(
    block_table_ptr,
    block_table_stride,
    idx_mapping_ptr,
    num_cached_tokens_ptr,
    seq_lens_ptr,
    block_size,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    req_state_idx = tl.load(idx_mapping_ptr + req_idx)
    num_cached = tl.load(num_cached_tokens_ptr + req_state_idx)
    shift = num_cached // block_size
    if shift == 0:
        return
    row_ptr = block_table_ptr + req_idx.to(tl.int64) * block_table_stride
    # Only the blocks the shifted sequence still references need to move;
    # seq_lens holds the cache-shifted draft length (written by
    # _prepare_dflash_inputs_kernel, which must run first).
    seq_len = tl.load(seq_lens_ptr + req_idx)
    num_needed = (seq_len + block_size - 1) // block_size
    num_remaining = tl.minimum(block_table_stride - shift, num_needed)
    # In-place left shift is safe: iterations run in ascending order and each
    # loads its chunk (from offset + shift) before storing (at offset), so no
    # store ever precedes a load of the same element.
    # Keep iterations strictly ordered. Compiler software pipelining may start
    # a store before a later overlapping source load has completed.
    for i in tl.range(
        0,
        num_remaining,
        BLOCK_SIZE,
        num_stages=1,
        loop_unroll_factor=1,
    ):
        offset = i + tl.arange(0, BLOCK_SIZE)
        mask = offset < num_remaining
        block_ids = tl.load(row_ptr + offset + shift, mask=mask, other=0)
        # Source and destination overlap for shifts smaller than BLOCK_SIZE.
        # Ensure every lane has consumed its source before any lane stores.
        tl.debug_barrier()
        tl.store(row_ptr + offset, block_ids, mask=mask)


def shift_draft_block_tables(
    # [max_num_reqs, max_num_blocks]
    block_table: torch.Tensor,
    # [num_reqs]
    idx_mapping: torch.Tensor,
    # [max_num_reqs]
    num_cached_tokens: torch.Tensor,
    # [num_reqs] cache-shifted draft sequence lengths
    seq_lens: torch.Tensor,
    block_size: int,
) -> None:
    """Shift each request's draft block-table row left by its cache-restored
    whole blocks, hiding slots that hold no draft context KV from the draft's
    attention. Must run after prepare_dflash_inputs (slot mappings index the
    unshifted table, and seq_lens must already hold the shifted lengths)."""
    num_reqs = idx_mapping.shape[0]
    _shift_draft_block_tables_kernel[(num_reqs,)](
        block_table,
        block_table.stride(0),
        idx_mapping,
        num_cached_tokens,
        seq_lens,
        block_size,
        BLOCK_SIZE=1024,  # type: ignore
    )
